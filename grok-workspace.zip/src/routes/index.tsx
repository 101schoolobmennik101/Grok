import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, type ComponentType } from "react";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [App, setApp] = useState<ComponentType | null>(null);

  useEffect(() => {
    let alive = true;
    void import("@/components/yard/YardApp").then((mod) => {
      if (alive) setApp(() => mod.YardApp);
    });
    return () => {
      alive = false;
    };
  }, []);

  if (!App) return <Boot />;
  return <App />;
}

function Boot() {
  return (
    <main className="yard">
      <header className="hud-top">
        <h1 className="font-display text-3xl leading-none text-fg">Гравидвор</h1>
        <p className="mt-2 max-w-xs text-sm leading-normal text-muted">Собираем двор…</p>
      </header>
    </main>
  );
}

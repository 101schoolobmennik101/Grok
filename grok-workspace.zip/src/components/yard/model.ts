export type ShapeKind = "sphere" | "box" | "cylinder";
export type Tool = ShapeKind | "drag" | "look";

export const PIT = 6.4;
export const WALL_H = 2.2;
export const WALL_T = 0.42;
export const MAX_BODIES = 36;

export const COLORS = {
  sphere: ["#c45c4a", "#a84b3d", "#d27a64"],
  box: ["#d9c7a4", "#cbb892", "#e6d7b6"],
  cylinder: ["#5f8f86", "#4d7c74", "#7aa399"],
} as const;

export const FLOOR = "#c4beb2";
export const WALL = "#8f897e";
export const APRON = "#191816";
export const PAPER = "#f4efe6";

export type BodySpec = {
  id: number;
  kind: ShapeKind;
  position: [number, number, number];
  rotation: [number, number, number];
  linvel: [number, number, number];
  angvel: [number, number, number];
  radius: number;
  half: [number, number, number];
  cylH: number;
  cylR: number;
  color: string;
};

let seq = 1;

function nextId() {
  seq += 1;
  return seq;
}

function spec(
  partial: Pick<BodySpec, "kind" | "position"> & Partial<BodySpec>,
): BodySpec {
  return {
    id: nextId(),
    rotation: [0, 0, 0],
    linvel: [0, 0, 0],
    angvel: [0, 0, 0],
    radius: 0.42,
    half: [0.37, 0.37, 0.37],
    cylH: 0.43,
    cylR: 0.34,
    color: COLORS[partial.kind][0],
    ...partial,
  };
}

export function createSeed(): BodySpec[] {
  const box: [number, number, number] = [0.38, 0.38, 0.38];
  return [
    spec({ kind: "box", position: [-0.4, 0.38, 0], half: box, color: COLORS.box[0] }),
    spec({ kind: "box", position: [0.4, 0.38, 0], half: box, color: COLORS.box[1] }),
    spec({ kind: "box", position: [0, 1.18, 0], half: box, color: COLORS.box[2] }),
    spec({
      kind: "sphere",
      position: [0.02, 1.96, 0.02],
      radius: 0.36,
      color: COLORS.sphere[0],
    }),
    spec({
      kind: "sphere",
      position: [-2.15, 0.32, 1.55],
      radius: 0.32,
      color: COLORS.sphere[1],
    }),
    spec({
      kind: "sphere",
      position: [2.15, 2.5, 1.15],
      radius: 0.36,
      linvel: [0.15, 0, 0],
      color: COLORS.sphere[2],
    }),
    spec({
      kind: "cylinder",
      position: [1.85, 0.46, -1.45],
      cylH: 0.46,
      cylR: 0.32,
      color: COLORS.cylinder[0],
    }),
    spec({
      kind: "cylinder",
      position: [-1.7, 0.4, -1.65],
      cylH: 0.4,
      cylR: 0.3,
      rotation: [0, 0.4, 0],
      color: COLORS.cylinder[1],
    }),
    spec({
      kind: "box",
      position: [0.15, 0.34, -2.15],
      half: [0.42, 0.34, 0.34],
      rotation: [0, 0.2, 0],
      color: COLORS.box[0],
    }),
  ];
}

export function makeBody(
  kind: ShapeKind,
  position: [number, number, number],
  linvel: [number, number, number],
  spin: number,
  uniform = false,
): BodySpec {
  const jitter = uniform ? 1 : 0.9 + Math.random() * 0.18;
  const color = COLORS[kind][Math.floor(Math.random() * COLORS[kind].length)] ?? COLORS[kind][0];
  const spinVec: [number, number, number] = [
    (Math.random() - 0.5) * spin,
    (Math.random() - 0.5) * spin,
    (Math.random() - 0.5) * spin,
  ];
  if (kind === "sphere") {
    return spec({
      kind,
      position,
      linvel,
      angvel: spinVec,
      radius: 0.42 * jitter,
      color,
      rotation: [0, Math.random() * Math.PI, 0],
    });
  }
  if (kind === "box") {
    const s = 0.37 * jitter;
    return spec({
      kind,
      position,
      linvel,
      angvel: spinVec,
      half: [s, s, s],
      color,
      rotation: uniform
        ? [0, (Math.random() - 0.5) * 0.15, 0]
        : [(Math.random() - 0.5) * 0.4, Math.random() * Math.PI, (Math.random() - 0.5) * 0.4],
    });
  }
  return spec({
    kind,
    position,
    linvel,
    angvel: spinVec,
    cylH: 0.43 * jitter,
    cylR: 0.34 * jitter,
    color,
    rotation: [0, Math.random() * Math.PI, 0],
  });
}

export function makeTower(): BodySpec[] {
  const bodies: BodySpec[] = [];
  for (let i = 0; i < 6; i += 1) {
    bodies.push(
      makeBody(
        "box",
        [(Math.random() - 0.5) * 0.08, 3.1 + i * 0.86, (Math.random() - 0.5) * 0.08],
        [0, -0.4, 0],
        0,
        true,
      ),
    );
  }
  return bodies;
}

export function extentAlong(
  kind: ShapeKind,
  radius: number,
  half: [number, number, number],
  cylH: number,
  cylR: number,
  nx: number,
  ny: number,
  nz: number,
) {
  const ax = Math.abs(nx);
  const ay = Math.abs(ny);
  const az = Math.abs(nz);
  if (kind === "sphere") return radius;
  if (kind === "box") return half[0] * ax + half[1] * ay + half[2] * az;
  return cylH * ay + cylR * (ax + az);
}

export function isShape(tool: Tool): tool is ShapeKind {
  return tool === "sphere" || tool === "box" || tool === "cylinder";
}

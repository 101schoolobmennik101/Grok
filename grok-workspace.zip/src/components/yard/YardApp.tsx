import { Canvas } from "@react-three/fiber";
import { Suspense, useEffect } from "react";
import { Box, Circle, Cylinder, Hand, Layers, Orbit, Trash2 } from "lucide-react";
import { MAX_BODIES, isShape, type Tool } from "@/components/yard/model";
import { Scene, configureRenderer } from "@/components/yard/scene";
import { useYard } from "@/components/yard/store";

const STORAGE_KEY = "gravydvor:v1";

const TOOLS: Array<{ id: Tool; label: string; icon: typeof Circle; shortcut: string }> = [
  { id: "sphere", label: "Сфера", icon: Circle, shortcut: "1" },
  { id: "box", label: "Куб", icon: Box, shortcut: "2" },
  { id: "cylinder", label: "Цилиндр", icon: Cylinder, shortcut: "3" },
  { id: "drag", label: "Тянуть", icon: Hand, shortcut: "4" },
  { id: "look", label: "Обзор", icon: Orbit, shortcut: "5" },
];

function hintFor(tool: Tool, holding: boolean) {
  if (holding) return "Отпустите — фигура полетит по инерции.";
  if (tool === "drag") return "Схватите фигуру и тащите. Отпускание задаёт скорость.";
  if (tool === "look") return "Тяните для обзора. Колёсико или два пальца — масштаб.";
  return "Клик роняет фигуру. Проведите по двору — бросок.";
}

function persist(tool: Tool, gravity: number, restitution: number) {
  try {
    window.localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify({ version: 1, tool, gravity, restitution }),
    );
  } catch {
    /* private mode / quota */
  }
}

export function YardApp() {
  const tool = useYard((state) => state.tool);
  const gravity = useYard((state) => state.gravity);
  const restitution = useYard((state) => state.restitution);
  const holding = useYard((state) => state.holding);
  const count = useYard((state) => state.bodies.length);
  const setTool = useYard((state) => state.setTool);
  const setGravity = useYard((state) => state.setGravity);
  const setRestitution = useYard((state) => state.setRestitution);
  const clear = useYard((state) => state.clear);
  const tower = useYard((state) => state.tower);

  useEffect(() => {
    persist(tool, gravity, restitution);
  }, [tool, gravity, restitution]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target;
      if (target instanceof HTMLElement && target.closest("input, textarea")) return;
      const next: Record<string, Tool> = {
        "1": "sphere",
        "2": "box",
        "3": "cylinder",
        "4": "drag",
        "5": "look",
      };
      const toolKey = next[event.key];
      if (toolKey) {
        useYard.getState().setTool(toolKey);
        return;
      }
      if (event.key === "c" || event.key === "C") useYard.getState().clear();
      if (event.key === "b" || event.key === "B") useYard.getState().tower();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <main
      className="yard"
      data-tool={tool}
      data-holding={holding ? "true" : "false"}
      onContextMenu={(event) => event.preventDefault()}
    >
      <Canvas
        shadows
        dpr={[1, 1.6]}
        camera={{ position: [8.4, 7.1, 9.3], fov: 38, near: 0.1, far: 80 }}
        gl={{ antialias: true, alpha: false, powerPreference: "high-performance" }}
        onCreated={({ gl }) => configureRenderer(gl)}
      >
        <Suspense fallback={null}>
          <Scene />
        </Suspense>
      </Canvas>

      <header className="hud-top">
        <div>
          <h1 className="font-display text-3xl leading-none text-fg">Гравидвор</h1>
          <p className="mt-2 max-w-xs text-sm leading-normal text-muted">{hintFor(tool, holding)}</p>
        </div>
        <p className="shrink-0 pt-1 text-sm text-muted tabular-nums">
          <span className="text-fg">{count}</span>
          <span> / {MAX_BODIES}</span>
          {count >= MAX_BODIES ? <span className="mt-1 block text-right">лимит</span> : null}
        </p>
      </header>

      <section className="dock" aria-label="Инструменты двора">
        <div className="grid grid-cols-5 gap-1.5" role="toolbar" aria-label="Фигуры и режим">
          {TOOLS.map((item) => {
            const Icon = item.icon;
            const active = tool === item.id;
            return (
              <button
                key={item.id}
                type="button"
                className="tool"
                data-active={active ? "true" : "false"}
                aria-pressed={active}
                aria-keyshortcuts={item.shortcut}
                onClick={() => setTool(item.id)}
              >
                <Icon className="size-4" strokeWidth={1.75} aria-hidden="true" />
                <span className="text-xs leading-none">{item.label}</span>
              </button>
            );
          })}
        </div>

        <div className="mt-3 grid grid-cols-2 gap-3">
          <label className="block min-w-0">
            <span className="flex items-baseline justify-between gap-2 text-xs text-muted">
              <span>Гравитация</span>
              <span className="tabular-nums text-fg">{gravity.toFixed(1)}</span>
            </span>
            <input
              className="range"
              type="range"
              min={0}
              max={22}
              step={0.1}
              value={gravity}
              aria-label="Гравитация"
              aria-valuemin={0}
              aria-valuemax={22}
              aria-valuenow={Number(gravity.toFixed(1))}
              aria-valuetext={`${gravity.toFixed(1)} метров в секунду в квадрате`}
              onChange={(event) => setGravity(Number(event.target.value))}
            />
          </label>
          <label className="block min-w-0">
            <span className="flex items-baseline justify-between gap-2 text-xs text-muted">
              <span>Отскок</span>
              <span className="tabular-nums text-fg">{restitution.toFixed(2)}</span>
            </span>
            <input
              className="range"
              type="range"
              min={0}
              max={0.92}
              step={0.01}
              value={restitution}
              aria-label="Отскок"
              aria-valuemin={0}
              aria-valuemax={0.92}
              aria-valuenow={Number(restitution.toFixed(2))}
              aria-valuetext={restitution.toFixed(2)}
              onChange={(event) => setRestitution(Number(event.target.value))}
            />
          </label>
        </div>

        <div className="mt-1 grid grid-cols-2 gap-2">
          <button type="button" className="action" onClick={tower} aria-keyshortcuts="B">
            <Layers className="size-4" strokeWidth={1.75} aria-hidden="true" />
            Башня
          </button>
          <button type="button" className="action" onClick={clear} disabled={count === 0} aria-keyshortcuts="C">
            <Trash2 className="size-4" strokeWidth={1.75} aria-hidden="true" />
            Очистить
          </button>
        </div>
      </section>
    </main>
  );
}

void isShape;

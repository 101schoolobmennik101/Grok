import { OrbitControls } from "@react-three/drei";
import { useFrame, useThree, type ThreeEvent } from "@react-three/fiber";
import {
  BallCollider,
  CuboidCollider,
  CylinderCollider,
  Physics,
  RigidBody,
  useBeforePhysicsStep,
  useRapier,
  type RapierRigidBody,
} from "@react-three/rapier";
import { createContext, memo, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import {
  ACESFilmicToneMapping,
  CanvasTexture,
  MOUSE,
  MathUtils,
  PCFSoftShadowMap,
  Plane,
  Raycaster,
  RepeatWrapping,
  SRGBColorSpace,
  TOUCH,
  Vector3,
  type Group,
  type Mesh,
  type MeshStandardMaterial,
} from "three";
import type { OrbitControls as OrbitImpl } from "three/examples/jsm/controls/OrbitControls.js";
import {
  APRON,
  COLORS,
  FLOOR,
  MAX_BODIES,
  PAPER,
  PIT,
  WALL,
  WALL_H,
  WALL_T,
  extentAlong,
  isShape,
  makeBody,
  type BodySpec,
  type ShapeKind,
} from "@/components/yard/model";
import { useYard } from "@/components/yard/store";

const BG = "#141311";
const LIMIT = PIT - 0.75;

let draggedId: number | null = null;

const hitApi = {
  onSurfacePointerDown: (_event: ThreeEvent<PointerEvent>) => {},
  onBodyPointerDown: (_event: ThreeEvent<PointerEvent>, _body: RapierRigidBody, _id: number) => {},
};

const HitContext = createContext(hitApi);

type Gesture = {
  pointerId: number;
  start: Vector3;
  startNormal: Vector3;
};

type Drag = {
  pointerId: number;
  id: number;
  body: RapierRigidBody;
  plane: Plane;
  offset: Vector3;
  desired: Vector3;
  last: Vector3;
  prev: Vector3;
  lastT: number;
  prevT: number;
};

function worldNormal(event: ThreeEvent<PointerEvent>) {
  const normal = new Vector3(0, 1, 0);
  if (event.face) {
    normal.copy(event.face.normal).transformDirection(event.object.matrixWorld);
    if (normal.dot(event.ray.direction) > 0) normal.negate();
  }
  if (normal.lengthSq() < 1e-6) normal.set(0, 1, 0);
  return normal.normalize();
}

function nominalLift(kind: ShapeKind, normal: Vector3) {
  return extentAlong(kind, 0.42, [0.37, 0.37, 0.37], 0.43, 0.34, normal.x, normal.y, normal.z);
}

function useGridTexture() {
  const texture = useMemo(() => {
    const size = 512;
    const canvas = document.createElement("canvas");
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext("2d");
    if (!ctx) return null;
    ctx.fillStyle = FLOOR;
    ctx.fillRect(0, 0, size, size);
    ctx.strokeStyle = "rgba(48, 42, 34, 0.22)";
    ctx.lineWidth = 2;
    const cells = 16;
    const step = size / cells;
    for (let i = 0; i <= cells; i += 1) {
      ctx.beginPath();
      ctx.moveTo(i * step, 0);
      ctx.lineTo(i * step, size);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, i * step);
      ctx.lineTo(size, i * step);
      ctx.stroke();
    }
    const map = new CanvasTexture(canvas);
    map.colorSpace = SRGBColorSpace;
    map.wrapS = RepeatWrapping;
    map.wrapT = RepeatWrapping;
    map.anisotropy = 8;
    return map;
  }, []);

  useEffect(() => {
    return () => texture?.dispose();
  }, [texture]);

  return texture;
}

function CameraRig() {
  const tool = useYard((state) => state.tool);
  const orbit = useRef<OrbitImpl>(null);
  const look = tool === "look";

  return (
    <OrbitControls
      ref={orbit}
      enableDamping
      dampingFactor={0.08}
      enablePan={false}
      minDistance={6.5}
      maxDistance={22}
      minPolarAngle={0.28}
      maxPolarAngle={1.28}
      target={[0, 0.55, 0]}
      mouseButtons={{
        LEFT: look ? MOUSE.ROTATE : (-1 as MOUSE),
        MIDDLE: MOUSE.DOLLY,
        RIGHT: MOUSE.ROTATE,
      }}
      touches={{
        ONE: look ? TOUCH.ROTATE : (-1 as TOUCH),
        TWO: TOUCH.DOLLY_PAN,
      }}
    />
  );
}

function SyncRestitution() {
  const restitution = useYard((state) => state.restitution);
  const { world } = useRapier();

  useEffect(() => {
    world.forEachCollider((collider) => {
      collider.setRestitution(restitution);
    });
  }, [restitution, world]);

  return null;
}

function Court() {
  const api = useContext(HitContext);
  const grid = useGridTexture();
  const [bounce] = useState(() => useYard.getState().restitution);
  const span = (PIT + WALL_T) * 2;
  const walls: Array<{ position: [number, number, number]; args: [number, number, number] }> = [
    { position: [PIT + WALL_T / 2, WALL_H / 2, 0], args: [WALL_T, WALL_H, span] },
    { position: [-(PIT + WALL_T / 2), WALL_H / 2, 0], args: [WALL_T, WALL_H, span] },
    { position: [0, WALL_H / 2, PIT + WALL_T / 2], args: [span, WALL_H, WALL_T] },
    { position: [0, WALL_H / 2, -(PIT + WALL_T / 2)], args: [span, WALL_H, WALL_T] },
  ];

  return (
    <>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.03, 0]} receiveShadow>
        <planeGeometry args={[48, 48]} />
        <meshStandardMaterial color={APRON} roughness={1} metalness={0} side={2} />
      </mesh>

      <mesh
        rotation={[-Math.PI / 2, 0, 0]}
        position={[0, 0.004, 0]}
        receiveShadow
        onPointerDown={api.onSurfacePointerDown}
      >
        <planeGeometry args={[PIT * 2, PIT * 2]} />
        <meshStandardMaterial map={grid ?? undefined} color={grid ? "#ffffff" : FLOOR} roughness={0.92} side={2} />
      </mesh>

      {walls.map((wall) => (
        <mesh
          key={wall.position.join(":")}
          position={wall.position}
          castShadow
          receiveShadow
          onPointerDown={api.onSurfacePointerDown}
        >
          <boxGeometry args={wall.args} />
          <meshStandardMaterial color={WALL} roughness={0.86} metalness={0.02} side={2} />
        </mesh>
      ))}

      <RigidBody type="fixed" colliders={false} friction={1}>
        <CuboidCollider
          args={[PIT + WALL_T, 0.3, PIT + WALL_T]}
          position={[0, -0.3, 0]}
          friction={0.96}
          restitution={bounce}
        />
        {walls.map((wall) => (
          <CuboidCollider
            key={wall.position.join(":")}
            args={[wall.args[0] / 2, wall.args[1] / 2, wall.args[2] / 2]}
            position={wall.position}
            friction={0.86}
            restitution={bounce}
          />
        ))}
      </RigidBody>
    </>
  );
}

const DynBody = memo(function DynBody({ spec }: { spec: BodySpec }) {
  const api = useContext(HitContext);
  const ref = useRef<RapierRigidBody>(null);
  const mat = useRef<MeshStandardMaterial>(null);
  const gone = useRef(false);
  const [bounce] = useState(() => useYard.getState().restitution);

  useEffect(() => {
    const body = ref.current;
    if (!body) return;
    body.setLinvel({ x: spec.linvel[0], y: spec.linvel[1], z: spec.linvel[2] }, true);
    body.setAngvel({ x: spec.angvel[0], y: spec.angvel[1], z: spec.angvel[2] }, true);
  }, [spec]);

  useFrame(() => {
    const material = mat.current;
    if (material && material.userData.hot !== (draggedId === spec.id)) {
      const hot = draggedId === spec.id;
      material.userData.hot = hot;
      material.emissive.set(hot ? "#6d5346" : "#000000");
      material.emissiveIntensity = hot ? 0.45 : 0;
    }
    const body = ref.current;
    if (!body || gone.current || draggedId === spec.id || !body.isValid()) return;
    const t = body.translation();
    if (t.y < -2 || Math.abs(t.x) > PIT + 4 || Math.abs(t.z) > PIT + 4) {
      gone.current = true;
      useYard.getState().removeBody(spec.id);
    }
  });

  const finish = spec.kind === "sphere" ? { roughness: 0.42, metalness: 0.03 } : spec.kind === "box" ? { roughness: 0.78, metalness: 0.02 } : { roughness: 0.36, metalness: 0.2 };

  return (
    <RigidBody
      ref={ref}
      position={spec.position}
      rotation={spec.rotation}
      colliders={false}
      ccd
      canSleep
      linearDamping={0.08}
      angularDamping={0.22}
      additionalSolverIterations={2}
    >
      {spec.kind === "sphere" ? (
        <BallCollider args={[spec.radius]} friction={0.72} restitution={bounce} />
      ) : null}
      {spec.kind === "box" ? (
        <CuboidCollider args={spec.half} friction={0.8} restitution={bounce} />
      ) : null}
      {spec.kind === "cylinder" ? (
        <CylinderCollider args={[spec.cylH, spec.cylR]} friction={0.74} restitution={bounce} />
      ) : null}
      <mesh
        castShadow
        receiveShadow
        onPointerDown={(event) => {
          const body = ref.current;
          if (body) api.onBodyPointerDown(event, body, spec.id);
        }}
      >
        {spec.kind === "sphere" ? <sphereGeometry args={[spec.radius, 32, 24]} /> : null}
        {spec.kind === "box" ? (
          <boxGeometry args={[spec.half[0] * 2, spec.half[1] * 2, spec.half[2] * 2]} />
        ) : null}
        {spec.kind === "cylinder" ? (
          <cylinderGeometry args={[spec.cylR, spec.cylR, spec.cylH * 2, 28]} />
        ) : null}
        <meshStandardMaterial ref={mat} color={spec.color} roughness={finish.roughness} metalness={finish.metalness} />
      </mesh>
    </RigidBody>
  );
});

function Bodies() {
  const bodies = useYard((state) => state.bodies);
  return (
    <>
      {bodies.map((body) => (
        <DynBody key={body.id} spec={body} />
      ))}
    </>
  );
}

function Interaction({ children }: { children: ReactNode }) {
  const { rapier, world } = useRapier();
  const gl = useThree((state) => state.gl);
  const ray = useMemo(() => new rapier.Ray({ x: 0, y: 4, z: 0 }, { x: 0, y: -1, z: 0 }), [rapier]);
  const caster = useMemo(() => new Raycaster(), []);
  const over = useRef(false);
  const hasHit = useRef(false);
  const gesture = useRef<Gesture | null>(null);
  const drag = useRef<Drag | null>(null);
  const ghost = useRef<Group>(null);
  const ghostSphere = useRef<Mesh>(null);
  const ghostBox = useRef<Mesh>(null);
  const ghostCyl = useRef<Mesh>(null);
  const arrow = useRef<Group>(null);
  const end = useRef(new Vector3());
  const normal = useRef(new Vector3(0, 1, 0));
  const hit = useRef(new Vector3());
  const delta = useRef(new Vector3());
  const vel = useRef(new Vector3());

  const releaseBody = (fling: boolean) => {
    const current = drag.current;
    drag.current = null;
    draggedId = null;
    useYard.getState().setHolding(false);
    if (!current || !current.body.isValid()) return;
    current.body.setBodyType(rapier.RigidBodyType.Dynamic, true);
    if (!fling) {
      current.body.setLinvel({ x: 0, y: 0, z: 0 }, true);
      current.body.wakeUp();
      return;
    }
    const dt = Math.min(0.08, Math.max(1 / 120, current.lastT - current.prevT));
    let vx = (current.last.x - current.prev.x) / dt;
    let vy = (current.last.y - current.prev.y) / dt;
    let vz = (current.last.z - current.prev.z) / dt;
    const speed = Math.hypot(vx, vy, vz);
    const cap = 11;
    if (speed > cap) {
      const scale = cap / speed;
      vx *= scale;
      vy *= scale;
      vz *= scale;
    }
    if (speed < 0.4) {
      vx = 0;
      vy = 0;
      vz = 0;
    }
    current.body.setLinvel({ x: vx, y: vy, z: vz }, true);
    current.body.wakeUp();
  };

  const place = (kind: ShapeKind, point: Vector3, faceNormal: Vector3, mode: "drop" | "throw", velocity: Vector3) => {
    const draft = makeBody(kind, [0, 0, 0], [velocity.x, velocity.y, velocity.z], mode === "throw" ? 3.4 : 0.7);
    const lift =
      extentAlong(kind, draft.radius, draft.half, draft.cylH, draft.cylR, faceNormal.x, faceNormal.y, faceNormal.z) +
      0.05;
    let x = point.x + faceNormal.x * lift;
    let y = point.y + faceNormal.y * lift;
    let z = point.z + faceNormal.z * lift;
    if (mode === "drop" && faceNormal.y > 0.72) y += 1.65;
    x = MathUtils.clamp(x, -LIMIT, LIMIT);
    z = MathUtils.clamp(z, -LIMIT, LIMIT);
    y = MathUtils.clamp(y, 0.2, 8);
    draft.position = [x, y, z];
    useYard.getState().addBodies([draft]);
  };

  const commitThrow = () => {
    const current = gesture.current;
    gesture.current = null;
    if (arrow.current) arrow.current.visible = false;
    if (!current) return;
    const tool = useYard.getState().tool;
    if (!isShape(tool)) return;
    const point = hasHit.current ? end.current : current.start;
    delta.current.subVectors(point, current.start);
    const len = delta.current.length();
    if (len < 0.32) {
      place(tool, current.start, current.startNormal, "drop", vel.current.set(0, 0, 0));
      return;
    }
    const speed = Math.min(len * 3.8, 13);
    let vx = (delta.current.x / len) * speed;
    let vy = (delta.current.y / len) * speed;
    let vz = (delta.current.z / len) * speed;
    if (Math.abs(delta.current.y) / len < 0.45) {
      const horiz = Math.hypot(delta.current.x, delta.current.z);
      vy = Math.max(vy, Math.min(horiz * 0.85, 5.2));
    }
    place(tool, current.start, current.startNormal, "throw", vel.current.set(vx, vy, vz));
  };

  const commitThrowRef = useRef(commitThrow);
  const releaseRef = useRef(releaseBody);
  commitThrowRef.current = commitThrow;
  releaseRef.current = releaseBody;

  hitApi.onSurfacePointerDown = (event) => {
    if (event.button !== 0 || gesture.current || drag.current) return;
    const tool = useYard.getState().tool;
    if (!isShape(tool)) return;
    event.stopPropagation();
    gesture.current = {
      pointerId: event.pointerId,
      start: event.point.clone(),
      startNormal: worldNormal(event),
    };
  };

  hitApi.onBodyPointerDown = (event, body, id) => {
    if (event.button !== 0 || gesture.current || drag.current || !body.isValid()) return;
    const tool = useYard.getState().tool;
    event.stopPropagation();
    if (tool === "drag") {
      const translation = body.translation();
      const planeNormal = new Vector3();
      event.camera.getWorldDirection(planeNormal);
      const plane = new Plane().setFromNormalAndCoplanarPoint(planeNormal, event.point);
      const now = performance.now() / 1000;
      body.setBodyType(rapier.RigidBodyType.KinematicPositionBased, true);
      body.setLinvel({ x: 0, y: 0, z: 0 }, true);
      body.setAngvel({ x: 0, y: 0, z: 0 }, true);
      body.wakeUp();
      draggedId = id;
      useYard.getState().setHolding(true);
      drag.current = {
        pointerId: event.pointerId,
        id,
        body,
        plane,
        offset: new Vector3(translation.x - event.point.x, translation.y - event.point.y, translation.z - event.point.z),
        desired: new Vector3(translation.x, translation.y, translation.z),
        last: new Vector3(translation.x, translation.y, translation.z),
        prev: new Vector3(translation.x, translation.y, translation.z),
        lastT: now,
        prevT: now - 1 / 60,
      };
      return;
    }
    if (!isShape(tool)) return;
    gesture.current = {
      pointerId: event.pointerId,
      start: event.point.clone(),
      startNormal: worldNormal(event),
    };
  };

  useEffect(() => {
    const pointers = new Set<number>();
    const down = (event: PointerEvent) => {
      pointers.add(event.pointerId);
      if (pointers.size > 1) {
        gesture.current = null;
        if (arrow.current) arrow.current.visible = false;
        releaseRef.current(false);
      }
    };
    const up = (event: PointerEvent) => {
      const throwId = gesture.current?.pointerId;
      const dragId = drag.current?.pointerId;
      pointers.delete(event.pointerId);
      if (pointers.size > 0) {
        gesture.current = null;
        if (dragId === event.pointerId) releaseRef.current(false);
        return;
      }
      if (throwId === event.pointerId) commitThrowRef.current();
      if (dragId === event.pointerId) releaseRef.current(true);
    };
    window.addEventListener("pointerdown", down);
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
    return () => {
      window.removeEventListener("pointerdown", down);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
    };
  }, []);

  useEffect(() => {
    const el = gl.domElement;
    const enter = () => {
      over.current = true;
    };
    const leave = () => {
      over.current = false;
    };
    el.addEventListener("pointerenter", enter);
    el.addEventListener("pointerleave", leave);
    return () => {
      el.removeEventListener("pointerenter", enter);
      el.removeEventListener("pointerleave", leave);
    };
  }, [gl]);

  useBeforePhysicsStep(() => {
    const current = drag.current;
    if (!current || !current.body.isValid()) return;
    current.body.setNextKinematicTranslation({
      x: current.desired.x,
      y: current.desired.y,
      z: current.desired.z,
    });
  });

  useFrame((state) => {
    const tool = useYard.getState().tool;
    const currentDrag = drag.current;
    caster.setFromCamera(state.pointer, state.camera);

    if (currentDrag && currentDrag.body.isValid()) {
      if (caster.ray.intersectPlane(currentDrag.plane, hit.current)) {
        currentDrag.desired.set(
          MathUtils.clamp(hit.current.x + currentDrag.offset.x, -LIMIT, LIMIT),
          MathUtils.clamp(hit.current.y + currentDrag.offset.y, 0.25, 7.5),
          MathUtils.clamp(hit.current.z + currentDrag.offset.z, -LIMIT, LIMIT),
        );
      }
      const now = performance.now() / 1000;
      currentDrag.prev.copy(currentDrag.last);
      currentDrag.prevT = currentDrag.lastT;
      currentDrag.last.copy(currentDrag.desired);
      currentDrag.lastT = now;
      if (ghost.current) ghost.current.visible = false;
      if (arrow.current) arrow.current.visible = false;
      return;
    }

    const aiming = isShape(tool) && (over.current || gesture.current !== null);
    if (!aiming) {
      hasHit.current = false;
      if (ghost.current) ghost.current.visible = false;
      if (arrow.current) arrow.current.visible = false;
      return;
    }

    ray.origin.x = caster.ray.origin.x;
    ray.origin.y = caster.ray.origin.y;
    ray.origin.z = caster.ray.origin.z;
    ray.dir.x = caster.ray.direction.x;
    ray.dir.y = caster.ray.direction.y;
    ray.dir.z = caster.ray.direction.z;
    const found = world.castRayAndGetNormal(ray, 90, true);
    if (found) {
      const point = ray.pointAt(found.timeOfImpact);
      end.current.set(point.x, point.y, point.z);
      normal.current.set(found.normal.x, found.normal.y, found.normal.z);
      if (normal.current.dot(caster.ray.direction) > 0) normal.current.negate();
      hasHit.current = true;
    } else {
      hasHit.current = false;
    }

    const showGhost = isShape(tool) && (gesture.current ? true : hasHit.current);
    if (ghost.current && ghostSphere.current && ghostBox.current && ghostCyl.current && showGhost) {
      const point = gesture.current ? gesture.current.start : end.current;
      const face = gesture.current ? gesture.current.startNormal : normal.current;
      const lift = nominalLift(tool, face);
      ghost.current.visible = true;
      ghost.current.position.set(point.x + face.x * lift, point.y + face.y * lift, point.z + face.z * lift);
      ghostSphere.current.visible = tool === "sphere";
      ghostBox.current.visible = tool === "box";
      ghostCyl.current.visible = tool === "cylinder";
    } else if (ghost.current) {
      ghost.current.visible = false;
    }

    const currentGesture = gesture.current;
    if (arrow.current && currentGesture && hasHit.current) {
      delta.current.subVectors(end.current, currentGesture.start);
      const len = delta.current.length();
      if (len > 0.28) {
        arrow.current.visible = true;
        arrow.current.position.copy(currentGesture.start).addScaledVector(delta.current, 0.5);
        arrow.current.lookAt(end.current);
        arrow.current.scale.set(1, 1, len);
      } else {
        arrow.current.visible = false;
      }
    } else if (arrow.current) {
      arrow.current.visible = false;
    }
  }, 100);

  return (
    <HitContext.Provider value={hitApi}>
      {children}
      <group ref={ghost} visible={false}>
        <mesh ref={ghostSphere} raycast={() => null}>
          <sphereGeometry args={[0.42, 28, 20]} />
          <meshStandardMaterial color={COLORS.sphere[0]} transparent opacity={0.38} roughness={0.45} depthWrite={false} />
        </mesh>
        <mesh ref={ghostBox} raycast={() => null}>
          <boxGeometry args={[0.74, 0.74, 0.74]} />
          <meshStandardMaterial color={COLORS.box[0]} transparent opacity={0.38} roughness={0.7} depthWrite={false} />
        </mesh>
        <mesh ref={ghostCyl} raycast={() => null}>
          <cylinderGeometry args={[0.34, 0.34, 0.86, 24]} />
          <meshStandardMaterial color={COLORS.cylinder[0]} transparent opacity={0.38} roughness={0.4} depthWrite={false} />
        </mesh>
      </group>
      <group ref={arrow} visible={false}>
        <mesh rotation={[Math.PI / 2, 0, 0]} raycast={() => null}>
          <cylinderGeometry args={[0.035, 0.035, 1, 8]} />
          <meshBasicMaterial color={PAPER} />
        </mesh>
      </group>
    </HitContext.Provider>
  );
}

export function Scene() {
  const gravity = useYard((state) => state.gravity);

  return (
    <>
      <color attach="background" args={[BG]} />
      <fog attach="fog" args={[BG, 24, 50]} />
      <hemisphereLight args={["#f3eee4", "#3c3832", 0.55]} />
      <ambientLight intensity={0.22} />
      <directionalLight
        castShadow
        position={[7.5, 14, 5]}
        intensity={2.35}
        color="#fff3e4"
        shadow-mapSize-width={1024}
        shadow-mapSize-height={1024}
        shadow-bias={-0.00035}
        shadow-normalBias={0.04}
        shadow-camera-near={2}
        shadow-camera-far={36}
        shadow-camera-left={-12}
        shadow-camera-right={12}
        shadow-camera-top={12}
        shadow-camera-bottom={-12}
      />
      <directionalLight position={[-8, 7, -6]} intensity={0.38} color="#c5d2e2" />
      <CameraRig />
      <Physics
        gravity={[0, -gravity, 0]}
        timeStep={1 / 60}
        numSolverIterations={8}
        numInternalPgsIterations={2}
      >
        <SyncRestitution />
        <Interaction>
          <Court />
          <Bodies />
        </Interaction>
      </Physics>
    </>
  );
}

export function configureRenderer(gl: { toneMapping: number; toneMappingExposure: number; shadowMap: { enabled: boolean; type: number } }) {
  gl.toneMapping = ACESFilmicToneMapping;
  gl.toneMappingExposure = 1.05;
  gl.shadowMap.enabled = true;
  gl.shadowMap.type = PCFSoftShadowMap;
}

void MAX_BODIES;

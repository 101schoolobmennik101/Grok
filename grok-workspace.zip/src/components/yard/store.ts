import { create } from "zustand";
import {
  MAX_BODIES,
  createSeed,
  isShape,
  makeTower,
  type BodySpec,
  type Tool,
} from "@/components/yard/model";

const STORAGE_KEY = "gravydvor:v1";

type Persisted = {
  tool: Tool;
  gravity: number;
  restitution: number;
};

function readSettings(): Partial<Persisted> {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return {};
    const data = JSON.parse(raw) as Partial<Persisted> & { version?: number };
    if (data.version !== 1) return {};
    const next: Partial<Persisted> = {};
    if (data.tool && (isShape(data.tool) || data.tool === "drag" || data.tool === "look")) {
      next.tool = data.tool;
    }
    if (typeof data.gravity === "number" && data.gravity >= 0 && data.gravity <= 22) {
      next.gravity = data.gravity;
    }
    if (typeof data.restitution === "number" && data.restitution >= 0 && data.restitution <= 0.92) {
      next.restitution = data.restitution;
    }
    return next;
  } catch {
    return {};
  }
}

type YardState = Persisted & {
  holding: boolean;
  bodies: BodySpec[];
  setTool: (tool: Tool) => void;
  setGravity: (gravity: number) => void;
  setRestitution: (restitution: number) => void;
  setHolding: (holding: boolean) => void;
  addBodies: (bodies: BodySpec[]) => void;
  removeBody: (id: number) => void;
  clear: () => void;
  tower: () => void;
};

const saved = readSettings();

function trim(bodies: BodySpec[]) {
  if (bodies.length <= MAX_BODIES) return bodies;
  return bodies.slice(bodies.length - MAX_BODIES);
}

export const useYard = create<YardState>((set) => ({
  tool: saved.tool ?? "sphere",
  gravity: saved.gravity ?? 9.8,
  restitution: saved.restitution ?? 0.32,
  holding: false,
  bodies: createSeed(),
  setTool: (tool) => set({ tool }),
  setGravity: (gravity) => set({ gravity }),
  setRestitution: (restitution) => set({ restitution }),
  setHolding: (holding) => set({ holding }),
  addBodies: (incoming) => set((state) => ({ bodies: trim([...state.bodies, ...incoming]) })),
  removeBody: (id) => set((state) => ({ bodies: state.bodies.filter((body) => body.id !== id) })),
  clear: () => set({ bodies: [] }),
  tower: () => set((state) => ({ bodies: trim([...state.bodies, ...makeTower()]) })),
}));
